from tictactoe import TicTacToe
import numpy as np
from minimax import choose_next_move
import random

def print_game(game, p1_depth, p2_depth, s0=None):
    n = game.n
    s = (np.zeros((n, n)) if s0 is None else s0)
    print_board(s)
    print("")
    while True:
        s = choose_next_move(game, s, p1_depth, True)
        print_board(s)
        print("")
        if game.is_terminal(s)[0]:
            print("Winner: o")
            return
        if game.is_draw(s):
            print("Draw")
            return
        s = choose_next_move(game, s, p2_depth, False)
        print_board(s)
        print("")
        if game.is_terminal(s)[0]:
            print("Winner: x")
            return
        if game.is_draw(s):
            print("Draw")
            return

def play_game(game, p1_depth, p2_depth, s0=None):
    n = game.n
    s = (np.zeros((n, n)) if s0 is None else s0)
    while True:
        s = choose_next_move(game, s, p1_depth, True)
        if game.is_terminal(s)[0]:
            return 1
        if game.is_draw(s):
            return 0
        s = choose_next_move(game, s, p2_depth, False)
        if game.is_terminal(s)[0]:
            return -1
        if game.is_draw(s):
            return 0

def print_board(s):
    for i in range(s.shape[0]):
        line =  ""
        for j in range(s.shape[1]):
            if s[i, j] == 1:
                line += "o "
            elif s[i, j] == -1:
                line += "x "
            if s[i, j] == 0:
                line += ". "
        print(line)

if __name__=="__main__":
    from tictactoe import TicTacToeModified
    game = TicTacToeModified(5, 4)
    iteration = 0
    wins_matrix = np.loadtxt("experiment-data/wins-n5-m4.out", delimiter=",", dtype=int)
    while True:
        iteration += 1
        print("Tournament", iteration)
        players = set([0, 1, 2, 3])
        pairs = []
        while players:
            pair = set(random.sample(players, 2))
            pairs.append(list(pair))
            players -= pair
        # Semifinals:
        qualified =  [0, 0]
        print(f"{pairs[0][0]} vs {pairs[0][1]}")
        result = play_game(game, pairs[0][0], pairs[0][1])
        if result == 1:
            qualified[0] = pairs[0][0]
            wins_matrix[pairs[0][0], pairs[0][1]] += 1
        else:
            qualified[0] = pairs[0][1]
            wins_matrix[pairs[0][1], pairs[0][0]] += 1
        print(f"{pairs[1][0]} vs {pairs[1][1]}")
        result = play_game(game, pairs[1][0], pairs[1][1])
        if result == 1:
            qualified[1] = pairs[1][0]
            wins_matrix[pairs[1][0], pairs[1][1]] += 1
        else:
            qualified[1] = pairs[1][1]
            wins_matrix[pairs[1][1], pairs[1][0]] += 1
        # Finals:
        print(f"{qualified[0]} vs {qualified[1]}")
        result = play_game(game, qualified[0], qualified[1])
        if result == 1:
            winner = qualified[0]
            wins_matrix[qualified[0], qualified[1]] += 1
        else:
            winner = qualified[1]
            wins_matrix[qualified[1], qualified[0]] += 1
        print("Winner:", winner)
        with open("experiment-data/tournament-n5-m4.out", "a") as f:
            f.write(str(winner) + "\n")
        np.savetxt("experiment-data/wins-n5-m4.out", wins_matrix, delimiter=",")
        
    