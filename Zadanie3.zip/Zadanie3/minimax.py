import numpy as np
import random

def minimax(game, s, d, is_max_move):
    is_terminal = game.is_terminal(s)
    if is_terminal[0]:
        return 1000 * is_terminal[1] * (d + 1)
    if d==0:
        return game.h(s)

    U = game.get_successors(s, is_max_move)
    if len(U) == 0:
        return 0
    w = [0 for _ in range(len(U))]
    for i, u in enumerate(U):
        w[i] = minimax(game, u, d-1, not is_max_move)
    if is_max_move:
        return max(w)
    else:
        return min(w)


def choose_next_move(game, s, d, is_max_move):
    U = game.get_successors(s, is_max_move)
    w = [0 for _ in range(len(U))]
    for i, u in enumerate(U):
        w[i] = alfabeta(game, u, d, not is_max_move)
    if is_max_move:
        return get_best(w, U, True)
    else:
        return get_best(w, U, False)


def alfabeta(game, s, d, is_max_move, a=-np.inf, b=np.inf):
    is_terminal = game.is_terminal(s)
    if is_terminal[0]:
        return 1000 * is_terminal[1] * (d + 1)
    if d==0:
        return game.h(s)

    U = game.get_successors(s, is_max_move)
    if len(U) == 0:
        return 0

    if is_max_move:
        for u in U:
            a = max(a, alfabeta(game, u, d-1, False, a, b))
            if b <= a:
                return a
        return a
    else:
        for u in U:
            b = min(b, alfabeta(game, u, d-1, True, a, b))
            if b <= a:
                return b
        return b


def get_best(w, U, do_max):
    if do_max:
        best_w = max(w)
    else:
        best_w = min(w)
    good_ones = []
    for i, u in enumerate(U):
        if w[i] == best_w:
            good_ones.append(u)
    return random.choice(good_ones)
