from PyQt5.QtWidgets import *
from PyQt5 import QtCore, QtGui
from PyQt5.QtGui import *
from PyQt5.QtCore import *

import numpy as np

import sys

from tictactoe import TicTacToeModified
from minimax import choose_next_move


class Window(QMainWindow):
    def __init__(self):
        super().__init__()
        n = 5
        self.game = TicTacToeModified(n, 4)
        self.state = np.zeros((n, n))
        self.setWindowTitle("TicTacToe++")
        self.setGeometry(100, 100, 480, 480)
        self.UiComponents()
        self.show()
        self.opponent = 3
        self.your_turn = False
        if not self.your_turn:
            self.update_buttons(False)
            self.opponent_turn()

    def UiComponents(self):
        self.buttons = [[0 for _ in range(self.game.n)] for __ in range(self.game.n)]
        self.button_data = {}
        x, y = 90, 90
        for i in range(self.game.n):
            for j in range(self.game.n):
                button = QPushButton(self)
                button.setGeometry(x*i + 20, y*j + 20, 80, 80)
                button.setFont(QFont(QFont("Comic Sans", 17)))
                button.clicked.connect(self.button_pressed)
                self.button_data[button] = (i, j)
                self.buttons[j][i] = button
    
    def button_pressed(self):
        x, y = self.button_data[self.sender()]
        if self.your_turn:
            if self.state[x][y] != 0:
                return
            self.state[x][y] = 1
            self.update_buttons(False)
            self.opponent_turn()

    def update_buttons(self, enabled):
        for i in range(self.game.n):
            for j in range(self.game.n):
                self.buttons[j][i].setEnabled(enabled)
                if self.state[i][j] == 1:
                    self.buttons[j][i].setText("O")
                    self.buttons[j][i].setStyleSheet("background-color : #4e6891")
                elif self.state[i][j] == -1:
                    self.buttons[j][i].setText("X")
                    self.buttons[j][i].setStyleSheet("background-color : #8a5048")
    
    def opponent_turn(self):
        self.your_turn = False
        self.thread = QThread()
        self.worker = Worker(self)
        self.worker.caller = self
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.finished.connect(self.thread.quit)
        self.worker.finished.connect(self.worker.deleteLater)
        self.thread.finished.connect(self.thread.deleteLater)
        self.thread.start()


class Worker(QObject):
    
    finished = pyqtSignal()


    def run(self):
        self.caller.state = choose_next_move(self.caller.game, self.caller.state, self.caller.opponent, False)
        self.caller.update_buttons(True)
        self.caller.your_turn = True
        self.finished.emit()




if __name__=="__main__":
    App = QApplication(sys.argv)
    window = Window()
    sys.exit(App.exec())