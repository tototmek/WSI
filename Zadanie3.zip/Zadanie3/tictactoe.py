import numpy as np

class TicTacToe:

    def __init__(self, n):
        self.n = n
        self.masks = self.generate_masks()
        self.h_matrix = self.generate_h_matrix()
    
    def generate_h_matrix(self):
        mtx = sum(self.masks)
        return mtx
    
    def generate_masks(self):
        masks = []
        n = self.n
        for i in range(n):
            mask = np.zeros((n, n))
            mask[:, i] += 1
            masks.append(mask)
            mask = np.zeros((n, n))
            mask[i, :] += 1
            masks.append(mask)
        masks.append(np.eye(n))
        masks.append(np.flip(np.eye(n), axis=0))
        return masks

    def is_terminal(self, s):
        for mask in self.masks:
            total = np.sum(mask * s)
            if total == self.n:
                return True, 1
            elif total == -self.n:
                return True, -1
        return False, 0
    
    def is_draw(self, s):
        n = self.n
        for i in range(n):
            for j in range(n):
                if s[i, j] == 0:
                    return False
        return True
    
    def h(self, s):
        terminal_state = self.is_terminal(s)
        if terminal_state[0]:
            return terminal_state[1]
        else:
            return np.sum(self.h_matrix * s)

    def get_successors(self, s, is_max_move):
        new_val = (1 if is_max_move else -1)
        successors = []
        n = self.n
        for i in range(n):
            for j in range(n):
                if s[i, j] == 0:
                    new_s = np.copy(s)
                    new_s[i, j] = new_val
                    successors.append(new_s)
        return successors


class TicTacToeModified(TicTacToe):
    def __init__(self, n, m):
        self.m = m
        super().__init__(n)
    
    def generate_masks(self):
        # n = self.n
        # m = self.m
        # l = n+1-m
        # indices = np.array([[(i,  j) for j in range(n)] for i in range(n)])
        # self.indexed_masks = []
        # for i in range(n):
        #     for j in range(n):
        #         check_j = j < l
        #         check_i = i < l
        #         if check_j:
        #             self.indexed_masks.append(indices[i, j:j+m])
        #         if check_i:
        #             self.indexed_masks.append(indices[i:i+m, j])
        #         if check_j and check_i:
        #             m1 = []
        #             m2 = []
        #             for c in range(m):
        #                 m1.append(indices[j+c,i+c])
        #                 m2.append(indices[n-1-c,i+c])
        #             self.indexed_masks.append(m1)
        #             self.indexed_masks.append(m2)
        return super().generate_masks()
    
    def generate_h_matrix(self):
        n = self.n
        m = self.m
        l = n+1-m
        h_matrix = np.zeros((n,n))
        for i in range(n):
            for j in range(n):
                check_j = j < l
                check_i = i < l
                if check_j:
                    h_matrix[i, j:j+m] += 1
                if check_i:
                    h_matrix[i:i+m, j] += 1
                if check_j and check_i:
                    for c in range(m):
                        h_matrix[j+c,i+c] += 1
                        h_matrix[n-1-c,i+c] += 1
        return h_matrix
    
    def is_terminal(self, s):
        n = self.n
        m = self.m
        if np.sum(s**2) <= 2 * (m-1):
            return False, 0
        l = n+1-m
        for i in range(n):
            for j in range(n):
                check_j = j < l
                check_i = i < l
                if check_j:
                    total = sum(s[i, j:j+m])
                    if total == self.m:
                        return True, 1
                    if total == -self.m:
                        return True, -1
                if check_i:
                    total = sum(s[i:i+m, j])
                    if total == self.m:
                        return True, 1
                    if total == -self.m:
                        return True, -1
                if check_j and check_i:
                    total = 0
                    total_reverse = 0
                    for c in range(m):
                        total += s[j+c,i+c]
                        total_reverse += s[n-1-c,i+c]
                    if total == self.m:
                        return True, 1
                    if total == -self.m:
                        return True, -1
                    if total_reverse == self.m:
                        return True, 1
                    if total_reverse == -self.m:
                        return True, -1
        return False, 0

        # # Cooler, but much slower
        # for mask in self.masks:
        #     total = np.sum(mask * s)
        #     if total == self.m:
        #         return True, 1
        #     elif total == -self.m:
        #         return True, -1
        # return False, 0

        # # Or

        # for mask in self.indexed_masks:
        #     score = 0
        #     for element in mask:
        #         score += s[element[0], element[1]]
        #     if score == self.m:
        #         return True, 1
        #     if score == -self.m:
        #         return True, -1
        # return False, 0